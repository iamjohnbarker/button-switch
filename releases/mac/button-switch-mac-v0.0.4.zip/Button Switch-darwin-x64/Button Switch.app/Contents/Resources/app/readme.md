# Button Switch
## Control your ATEM and HyperDeck with a USB device
You can download and install the latest version of the app from the releases section.
Learn more at [heretorecord.com/button-switch](https://www.heretorecord.com/button-switch).
